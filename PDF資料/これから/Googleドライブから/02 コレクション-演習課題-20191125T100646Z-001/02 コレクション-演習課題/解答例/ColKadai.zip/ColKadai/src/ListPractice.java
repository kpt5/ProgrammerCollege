import java.util.ArrayList;
import java.util.List;

public class ListPractice {

	public static void main(String[] args) {

		//↓(1)の回答例：ココカラ

		Person sato = new Person("sato",28);
		Person monzen = new Person("monzen",22);
		Person suzuki = new Person("suzuki",31);

		List<Person> personList = new ArrayList<Person>();

		personList.add(sato);
		personList.add(monzen);
		personList.add(suzuki);

		//↑(1)の回答例：ココマデ

		//↓(2)の回答例：ココカラ

		for(Person p : personList){
			System.out.println(p.getName() + "は" +p.getAge()+"才");
		}

		//↑(2)の回答例：ココマデ

		System.out.print("\n\n");

		//↓(3)の回答例：ココカラ

		System.out.println("1件目は"+personList.get(0).getName()+"さんです");

		//↑(3)の回答例：ココマデ

	}
}